repo: Boom-Vitt/beauty-clinic-landing
branch: main

## Last sync
date: 2026-08-23T15:52:00Z
note: ยังไม่ได้ push — เชื่อมต่อ GitHub อ่านได้ แต่ commit จากที่นี่ไม่ได้ ต้อง push จากเครื่อง

### Updated in this project
- Landing page คลินิกเสริมความงาม โทนทอง-ครีม โครงตามเทมเพลตอ้างอิง
- ย้ายรูป 6 ไฟล์ + วิดีโอ hero มาเก็บใน assets/ (ไม่พึ่ง URL ที่หมดอายุแล้ว)
- โลโก้ BoomBigNose Group ใน header/footer + README ภาษาไทย

## Screen map
| Screen | Source |
| --- | --- |
| Landing page | beauty-clinic.dc.html, support.js, logo_BBNG.png, assets/* |
