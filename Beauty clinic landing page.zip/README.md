# ลมิรา คลินิก — Landing Page

Landing page คลินิกเสริมความงาม ภาษาไทย · หน้าเดียว · ไม่ต้อง build

## โครงสร้าง

```
beauty-clinic.dc.html   หน้าเว็บหลัก (เปิดในเบราว์เซอร์ได้ทันที)
support.js              runtime ของหน้า
logo_BBNG.png           โลโก้ BoomBigNose Group
assets/
  hero-loop.mp4         วิดีโอพื้นหลัง hero (8 วิ, 1080p, loop)
  clinic-interior.png   poster ของวิดีโอ
  treatment-room.png
  laser-device.png
  reception.png
  facial-care.png
  relax-neck.png
```

## ใช้งาน

เปิด `beauty-clinic.dc.html` ตรงๆ หรือเสิร์ฟด้วย static server ใดก็ได้:

```bash
python3 -m http.server 8000
```

## ดีไซน์

- สีหลัก `#C9A24D` (ทอง) · รอง `#FAF7F2` (ครีม) · ตัวอักษร `#2A2724`
- ฟอนต์ Noto Serif Thai (หัวข้อ) + Sarabun (เนื้อหา) + Parisienne (accent)
- Responsive ด้วย CSS grid `auto-fit` + `clamp()` — ไม่พึ่ง media query

## หมายเหตุด้านเนื้อหา

ข้อความบนหน้าเขียนแบบไม่การันตีผลลัพธ์ ไม่เคลมรักษาโรค และมีหมายเหตุ
"ผลลัพธ์ขึ้นอยู่กับสภาพผิวของแต่ละบุคคล" กับ "ควรปรึกษาแพทย์ก่อนเข้ารับบริการ" ใน footer
ชื่อคลินิก ที่อยู่ เบอร์โทร และรีวิว เป็นข้อมูลตัวอย่าง — ต้องแทนด้วยข้อมูลจริงก่อนเผยแพร่

ภาพและวิดีโอทั้งหมดสร้างด้วย AI (Phaya)
